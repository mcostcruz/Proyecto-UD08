package model;

public class Conexion {
    static final String HOST = "130.61.233.108:49153";
    static final String DATABASE = "Usuarios";
    static final String USER = "fabricio";
    static final String PASSWORD = "";
}
